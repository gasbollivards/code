#/bin/bash
clear
while true; do
  clear
  node lvlgen.js
done
